<?php

function bar() {
    return 'global bar';
}
