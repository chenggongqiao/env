<?php
$config->tree = new stdclass();
$config->tree->noBrowse = ',productdoc,projectdoc,';
