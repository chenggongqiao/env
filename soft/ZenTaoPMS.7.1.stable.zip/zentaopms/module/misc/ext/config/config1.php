<?php
$config->misc->key1 = 'value1';
