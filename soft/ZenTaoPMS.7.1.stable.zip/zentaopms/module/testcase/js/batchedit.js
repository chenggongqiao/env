$(function()
{
    $(".chosen").chosen(defaultChosenOptions);
})
