require 'cairo'

class FontOptionsTest < Test::Unit::TestCase
  include CairoTestUtils

  def setup
    @options = Cairo::FontOptions.new
  end

  def test_something
    # WRITE ME!
  end
end
